DATA ANALYTICS CAMPUS — DEPLOYMENT PACKAGE

Files:
- index.html: website
- robots.txt: search-engine crawling instructions
- sitemap.xml: sitemap template

IMPORTANT:
1. Upload the whole folder so index.html stays together with any referenced assets.
2. The current HTML references logo.png and logo files under logos/. Those assets must also be uploaded if you have them.
3. After you receive the final public domain, replace YOUR-DOMAIN.com in robots.txt and sitemap.xml.
4. The website can be shared immediately after publication. Google indexing is separate and can be requested through Google Search Console.
5. The HTML currently contains placeholder contact/social values for EMAIL, FB, IG and LI; replace these before publishing if you want those links to work.

Google indexing:
- Open Google Search Console.
- Add/verify the published website property.
- Submit https://YOUR-DOMAIN.com/sitemap.xml
- Use URL Inspection to request indexing for the homepage.

The site already contains a descriptive title and meta description and uses the Data Analytics Campus content in the uploaded HTML.
